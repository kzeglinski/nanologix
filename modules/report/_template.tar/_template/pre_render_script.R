# packages
library(vroom)
library(dplyr)
library(ggplot2)
library(stringr)
library(tidyr)
library(gt)
library(ComplexUpset)
library(crosstalk)
library(plotly)
library(DT)
library(distances)
library(ggtree)
#library(msa)
#library(seqinr)
# also need packages igraph, intergraph, ape, network, ggnetwork, TreeAndLeaf, cowplot, irlba, biostrings

# ggplot theme
theme_set(theme_minimal())
theme_update(text = element_text(size = 16))
theme_update(plot.title = element_text(face = "bold"))

# metadata
metadata <- vroom(fs::dir_ls(
    #path = "/vast/scratch/users/zeglinski.k/pfs230_d13d14/",
    glob = "*.csv"),
    col_select = c("sample_num", "library", "antigen", "round", "replicate", "panning_id")) %>%
    mutate(replicate = str_replace_all(replicate, "rep_", "Rep"))

# create replicate ID if required
if(!all(is.na(metadata$replicate))){
    metadata <- metadata %>%
        filter(round != 0) %>% # temporarily remove R0 samples
        group_by(library, antigen, round) %>%
        mutate(replicate_id = cur_group_id()) %>%
        # and give our replicates an informative name, not just a number
        mutate(replicate_id_informative =
            paste0(library, "_", antigen, "_round_", round)) %>%
        # create a unique ID for each pan (just a number is ok)
        ungroup() %>%
        bind_rows(filter(metadata, round == 0))
} else {
    metadata <- metadata %>%
        mutate(replicate_id_informative = NA)
}