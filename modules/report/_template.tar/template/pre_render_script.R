# packages
library(vroom)
library(dplyr)
library(ggplot2)
library(stringr)
library(tidyr)
library(gt)
library(ggside)
library(ComplexUpset)
library(stringdist)
library(crosstalk)
library(plotly)
library(DT)
library(distances)

# ggplot theme
theme_set(theme_minimal())
theme_update(text = element_text(size = 16))
theme_update(plot.title = element_text(face = "bold"))

# colour palettes
colour_palette <- c("#89C5DA", "#DA5724", "#8569D5", "#DC7F9B", "#D1A33D",
                    "#849324", "#2F599D", "#756767", "#58CCB7", "#0B6E4F",
                    "#950106", "#6c472c", "#983790", "#2c556c", "#db2b2e",
                    "#80af63", "#6c556b")

# metadata
metadata <- vroom(fs::dir_ls(
    "/vast/scratch/users/zeglinski.k/6cys_output/",
    glob = "*.csv"),
    col_select = c("sample_num", "library", "antigen", "round", "replicate")) %>%
    mutate(replicate = str_replace_all(replicate, "rep_", "Rep"))

# create replicate ID if required
if(!all(is.na(metadata$replicate))){
    metadata <- metadata %>%
        filter(round != 0) %>% # temporarily remove R0 samples
        group_by(library, antigen, round) %>%
        mutate(replicate_id = cur_group_id()) %>%
        # and give our replicates an informative name, not just a number
        mutate(replicate_id_informative =
            paste0(library, "_", antigen, "_round_", round)) %>%
        # create a unique ID for each pan (just a number is ok)
        ungroup() %>%
        bind_rows(filter(metadata, round == 0))
} else {
    metadata <- metadata %>%
        mutate(replicate_id_informative = NA)
}

# create panning ID if required
if(!all(metadata$round == 0)){
    metadata <- metadata %>%
        filter(round != 0) %>% # temporarily remove R0 samples
        group_by(library, antigen) %>%
        mutate(panning_id = as.character(cur_group_id())) %>%
        ungroup() %>%
        bind_rows(filter(metadata, round == 0))

    metadata <- metadata %>%
        group_by(library) %>%
        summarise(panning_id = paste0(unique(na.omit(panning_id)), collapse = "_")) %>%
        mutate(round = 0, replicate = NA) %>%
        right_join(metadata, by = c("library", "round", "replicate")) %>%
        mutate(panning_id = coalesce(panning_id.x, panning_id.y)) %>%
        select(-panning_id.x, -panning_id.y)
}